/*
* Copyright (c) Huawei Technologies Co., Ltd. 2020-2021. All rights reserved.
* gazelle is licensed under the Mulan PSL v2.
* You can use this software according to the terms and conditions of the Mulan PSL v2.
* You may obtain a copy of Mulan PSL v2 at:
*     http://license.coscl.org.cn/MulanPSL2
* THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
* PURPOSE.
* See the Mulan PSL v2 for more details.
*/

#define _GNU_SOURCE
#include <dlfcn.h>

#include <signal.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <stdarg.h>
#include <netinet/in.h>
#include <sys/epoll.h>
#include <unistd.h>

#include <lwip/posix_api.h>
#include <lwip/api.h>
#include <lwip/lwipsock.h>

#include "posix/lstack_epoll.h"
#include "posix/lstack_fcntl.h"
#include "posix/lstack_socket.h"
#include "posix/lstack_unistd.h"
#include "lstack_log.h"
#include "lstack_cfg.h"
#include "lstack_lwip.h"
#include "gazelle_base_func.h"
#include "lstack_thread_rpc.h"

enum KERNEL_LWIP_PATH {
    PATH_KERNEL = 0,
    PATH_LWIP,
    PATH_UNKNOW,
};

static inline enum KERNEL_LWIP_PATH select_path(int fd)
{
    struct lwip_sock *sock = posix_api->get_socket(fd);

    /* AF_UNIX case */
    if (!sock || unlikely(posix_api->is_chld)) {
        return PATH_KERNEL;
    }

    if (CONN_TYPE_IS_LIBOS(sock->conn)) {
        return PATH_LWIP;
    }

    if (CONN_TYPE_IS_HOST(sock->conn)) {
        return PATH_KERNEL;
    }

    return PATH_UNKNOW;
}

static inline int32_t do_epoll_create(int32_t size)
{
    if (unlikely(posix_api->is_chld)) {
        return posix_api->epoll_create_fn(size);
    }

    return lstack_epoll_create(size);
}

static inline int32_t do_epoll_ctl(int32_t epfd, int32_t op, int32_t fd, struct epoll_event* event)
{
    if (unlikely(posix_api->is_chld)) {
        return posix_api->epoll_ctl_fn(epfd, op, fd, event);
    }

    return lstack_epoll_ctl(epfd, op, fd, event);
}

static inline int32_t do_epoll_wait(int32_t epfd, struct epoll_event* events, int32_t maxevents, int32_t timeout)
{
    if (events == NULL || maxevents == 0) {
        GAZELLE_RETURN(EINVAL);
    }

    if (unlikely(posix_api->is_chld)) {
        return posix_api->epoll_wait_fn(epfd, events, maxevents, timeout);
    }

    if (epfd < 0) {
        GAZELLE_RETURN(EBADF);
    }

    if ((events == NULL) || (timeout < -1) || (maxevents <= 0)) {
        GAZELLE_RETURN(EINVAL);
    }

    return lstack_epoll_wait(epfd, events, maxevents, timeout);
}

static inline int32_t do_accept(int32_t s, struct sockaddr *addr, socklen_t *addrlen)
{
    if (addr == NULL || addrlen == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (select_path(s) == PATH_KERNEL) {
        return posix_api->accept_fn(s, addr, addrlen);
    }

    int32_t fd = stack_broadcast_accept(s, addr, addrlen);
    if (fd >= 0) {
        return fd;
    }

    return posix_api->accept_fn(s, addr, addrlen);
}

static inline int32_t do_accept4(int32_t s, struct sockaddr *addr, socklen_t *addrlen, int32_t flags)
{
    if (addr == NULL || addrlen == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (select_path(s) == PATH_KERNEL) {
        return posix_api->accept4_fn(s, addr, addrlen, flags);
    }

    if ((flags & SOCK_CLOEXEC) == 0) {
        return 0;
    }

    int32_t fd = stack_broadcast_accept(s, addr, addrlen);
    if (fd >= 0) {
        return fd;
    }

    return posix_api->accept4_fn(s, addr, addrlen, flags);
}

static inline int32_t do_bind(int32_t s, const struct sockaddr *name, socklen_t namelen)
{
    if (name == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (select_path(s) == PATH_KERNEL) {
        return posix_api->bind_fn(s, name, namelen);
    }

    int32_t ret = posix_api->bind_fn(s, name, namelen);
    if (ret < 0) {
        /* ip is not lstack, just return */
        if (!match_host_addr(((struct sockaddr_in *)name)->sin_addr.s_addr)) {
            return ret;
        }
    }

    return rpc_call_bind(s, name, namelen);
}

static inline int32_t do_connect(int32_t s, const struct sockaddr *name, socklen_t namelen)
{
    if (name == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (select_path(s) == PATH_KERNEL) {
        return posix_api->connect_fn(s, name, namelen);
    }

    int32_t ret = rpc_call_connect(s, name, namelen);
    if (ret == 0) {
        return ret;
    }

    ret = posix_api->connect_fn(s, name, namelen);
    if (ret == 0) {
        return ret;
    }

    return -1;
}

static inline int32_t do_listen(int32_t s, int32_t backlog)
{
    if (select_path(s) == PATH_KERNEL) {
        return posix_api->listen_fn(s, backlog);
    }

    int32_t ret = stack_broadcast_listen(s, backlog);
    if (ret != 0) {
        return ret;
    }

    return posix_api->listen_fn(s, backlog);
}

static inline int32_t do_getpeername(int32_t s, struct sockaddr *name, socklen_t *namelen)
{
    if (name == NULL || namelen == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (select_path(s) == PATH_LWIP) {
        return rpc_call_getpeername(s, name, namelen);
    }

    return posix_api->getpeername_fn(s, name, namelen);
}

static inline int32_t do_getsockname(int32_t s, struct sockaddr *name, socklen_t *namelen)
{
    if (name == NULL || namelen == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (select_path(s) == PATH_LWIP) {
        return rpc_call_getsockname(s, name, namelen);
    }

    return posix_api->getsockname_fn(s, name, namelen);
}

static inline int32_t do_getsockopt(int32_t s, int32_t level, int32_t optname, void *optval, socklen_t *optlen)
{
    if (select_path(s) == PATH_LWIP) {
        return rpc_call_getsockopt(s, level, optname, optval, optlen);
    }

    return posix_api->getsockopt_fn(s, level, optname, optval, optlen);
}

static inline int32_t do_setsockopt(int32_t s, int32_t level, int32_t optname, const void *optval, socklen_t optlen)
{
    if (select_path(s) == PATH_KERNEL) {
        return posix_api->setsockopt_fn(s, level, optname, optval, optlen);
    }

    /* we both set kernel and lwip */
    int32_t ret = posix_api->setsockopt_fn(s, level, optname, optval, optlen);
    if (ret != 0) {
        return ret;
    }

    return rpc_call_setsockopt(s, level, optname, optval, optlen);
}

static inline int32_t do_socket(int32_t domain, int32_t type, int32_t protocol)
{
    if ((domain != AF_INET && domain != AF_UNSPEC)
        || posix_api->is_chld) {
        return posix_api->socket_fn(domain, type, protocol);
    }

    return rpc_call_socket(domain, type, protocol);
}

static inline ssize_t do_recv(int32_t sockfd, void *buf, size_t len, int32_t flags)
{
    if (buf == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (len == 0) {
        return 0;
    }

    if (select_path(sockfd) == PATH_LWIP) {
        return read_stack_data(sockfd, buf, len, flags);
    }

    return posix_api->recv_fn(sockfd, buf, len, flags);
}

static inline ssize_t do_read(int32_t s, void *mem, size_t len)
{
    if (mem == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (len == 0) {
        return 0;
    }

    if (select_path(s) == PATH_LWIP) {
        return read_stack_data(s, mem, len, 0);
    }
    return posix_api->read_fn(s, mem, len);
}

static inline ssize_t gazelle_send(int32_t fd, const void *buf, size_t len, int32_t flags)
{
    if (buf == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (len == 0) {
        return 0;
    }

    struct lwip_sock *sock = get_socket(fd);
    if (sock == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    ssize_t send = write_stack_data(sock, buf, len);
    if (send < 0 || sock->have_rpc_send) {
        return send;
    }

    sock->have_rpc_send = true;
    ssize_t ret = rpc_call_send(fd, buf, len, flags);
    return (ret < 0) ? ret : send;
}

static inline ssize_t do_send(int32_t sockfd, const void *buf, size_t len, int32_t flags)
{
    if (select_path(sockfd) != PATH_LWIP) {
        return posix_api->send_fn(sockfd, buf, len, flags);
    }

    return gazelle_send(sockfd, buf, len, flags);
}

static inline ssize_t do_write(int32_t s, const void *mem, size_t size)
{
    if (select_path(s) != PATH_LWIP) {
        return posix_api->write_fn(s, mem, size);
    }

    return gazelle_send(s, mem, size, 0);
}

static inline ssize_t do_recvmsg(int32_t s, struct msghdr *message, int32_t flags)
{
    if (message == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (select_path(s) == PATH_LWIP) {
        return rpc_call_recvmsg(s, message, flags);
    }

    return posix_api->recv_msg(s, message, flags);
}

static inline ssize_t do_sendmsg(int32_t s, const struct msghdr *message, int32_t flags)
{
    if (message == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (select_path(s) == PATH_LWIP) {
        return rpc_call_sendmsg(s, message, flags);
    }

    return posix_api->send_msg(s, message, flags);
}

static inline int32_t do_close(int32_t s)
{
    if (select_path(s) == PATH_KERNEL) {
        return posix_api->close_fn(s);
    }

    return stack_broadcast_close(s);
}

static int32_t do_poll(struct pollfd *fds, nfds_t nfds, int32_t timeout)
{
    if (fds == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    if (unlikely(posix_api->is_chld) || nfds == 0) {
        return posix_api->poll_fn(fds, nfds, timeout);
    }

    return lstack_poll(fds, nfds, timeout);
}

static int32_t do_ppoll(struct pollfd *fds, nfds_t nfds, const struct timespec *tmo_p, const sigset_t *sigmask)
{
    int32_t ready;
    int32_t timeout;

    if (fds == NULL || tmo_p == NULL) {
        GAZELLE_RETURN(EINVAL);
    }

    // s * 1000 and ns / 1000000 -> ms
    timeout = (tmo_p == NULL) ? -1 : (tmo_p->tv_sec * 1000 + tmo_p->tv_nsec / 1000000);
    ready = do_poll(fds, nfds, timeout);

    return ready;
}

typedef int32_t (*sigaction_fn)(int32_t signum, const struct sigaction *act, struct sigaction *oldact);
static int32_t do_sigaction(int32_t signum, const struct sigaction *act, struct sigaction *oldact)
{
    if (posix_api == NULL) {
        sigaction_fn sf = (sigaction_fn)dlsym(RTLD_NEXT, "sigaction");
        if (sf == NULL) {
            return -1;
        }
        return sf(signum, act, oldact);
    }

    return lstack_sigaction(signum, act, oldact);
}

#define WRAP_VA_PARAM(_fd, _cmd, _lwip_fcntl, _fcntl_fn) \
    do { \
        unsigned long val; \
        va_list ap; \
        va_start(ap, _cmd); \
        val = va_arg(ap, typeof(val)); \
        va_end(ap); \
        if (select_path(_fd) == PATH_KERNEL) \
            return _fcntl_fn(_fd, _cmd, val); \
        int32_t ret = _fcntl_fn(_fd, _cmd, val); \
        if (ret == -1) \
            return ret; \
        return _lwip_fcntl(_fd, _cmd, val); \
    } while (0)


/*  --------------------------------------------------------
 *  -------  LD_PRELOAD mode replacement interface  --------
 *  --------------------------------------------------------
 */
int32_t epoll_create(int32_t size)
{
    return do_epoll_create(size);
}
int32_t epoll_ctl(int32_t epfd, int32_t op, int32_t fd, struct epoll_event* event)
{
    return do_epoll_ctl(epfd, op, fd, event);
}
int32_t epoll_wait(int32_t epfd, struct epoll_event* events, int32_t maxevents, int32_t timeout)
{
    return do_epoll_wait(epfd, events, maxevents, timeout);
}
int32_t fcntl64(int32_t s, int32_t cmd, ...)
{
    WRAP_VA_PARAM(s, cmd, lwip_fcntl, posix_api->fcntl64_fn);
}
int32_t fcntl(int32_t s, int32_t cmd, ...)
{
    WRAP_VA_PARAM(s, cmd, lwip_fcntl, posix_api->fcntl_fn);
}
int32_t ioctl(int32_t s, int32_t cmd, ...)
{
    WRAP_VA_PARAM(s, cmd, lwip_ioctl, posix_api->ioctl_fn);
}
int32_t accept(int32_t s, struct sockaddr *addr, socklen_t *addrlen)
{
    return do_accept(s, addr, addrlen);
}
int32_t accept4(int32_t s, struct sockaddr *addr, socklen_t *addrlen, int32_t flags)
{
    return do_accept4(s, addr, addrlen, flags);
}
int32_t bind(int32_t s, const struct sockaddr *name, socklen_t namelen)
{
    return do_bind(s, name, namelen);
}
int32_t connect(int32_t s, const struct sockaddr *name, socklen_t namelen)
{
    return do_connect(s, name, namelen);
}
int32_t listen(int32_t s, int32_t backlog)
{
    return do_listen(s, backlog);
}
int32_t getpeername(int32_t s, struct sockaddr *name, socklen_t *namelen)
{
    return do_getpeername(s, name, namelen);
}
int32_t getsockname(int32_t s, struct sockaddr *name, socklen_t *namelen)
{
    return do_getsockname(s, name, namelen);
}
int32_t getsockopt(int32_t s, int32_t level, int32_t optname, void *optval, socklen_t *optlen)
{
    return do_getsockopt(s, level, optname, optval, optlen);
}
int32_t setsockopt(int32_t s, int32_t level, int32_t optname, const void *optval, socklen_t optlen)
{
    return do_setsockopt(s, level, optname, optval, optlen);
}
int32_t socket(int32_t domain, int32_t type, int32_t protocol)
{
    return do_socket(domain, type, protocol);
}
ssize_t read(int32_t s, void *mem, size_t len)
{
    return do_read(s, mem, len);
}
ssize_t write(int32_t s, const void *mem, size_t size)
{
    return do_write(s, mem, size);
}
ssize_t __wrap_write(int32_t s, const void *mem, size_t size)
{
    return do_write(s, mem, size);
}
ssize_t recv(int32_t sockfd, void *buf, size_t len, int32_t flags)
{
    return do_recv(sockfd, buf, len, flags);
}
ssize_t send(int32_t sockfd, const void *buf, size_t len, int32_t flags)
{
    return do_send(sockfd, buf, len, flags);
}
ssize_t recvmsg(int32_t s, struct msghdr *message, int32_t flags)
{
    return do_recvmsg(s, message, flags);
}
ssize_t sendmsg(int32_t s, const struct msghdr *message, int32_t flags)
{
    return do_sendmsg(s, message, flags);
}
int32_t close(int32_t s)
{
    return do_close(s);
}
int32_t poll(struct pollfd *fds, nfds_t nfds, int32_t timeout)
{
    return do_poll(fds, nfds, timeout);
}
int32_t ppoll(struct pollfd *fds, nfds_t nfds, const struct timespec *tmo_p, const sigset_t *sigmask)
{
    return do_ppoll(fds, nfds, tmo_p, sigmask);
}
int32_t sigaction(int32_t signum, const struct sigaction *act, struct sigaction *oldact)
{
    return do_sigaction(signum, act, oldact);
}
pid_t fork(void)
{
    return lstack_fork();
}

/*  --------------------------------------------------------
 *  -------  Compile mode replacement interface  -----------
 *  --------------------------------------------------------
 */

int32_t __wrap_epoll_create(int32_t size)
{
    return do_epoll_create(size);
}
int32_t __wrap_epoll_ctl(int32_t epfd, int32_t op, int32_t fd, struct epoll_event* event)
{
    return do_epoll_ctl(epfd, op, fd, event);
}
int32_t __wrap_epoll_wait(int32_t epfd, struct epoll_event* events, int32_t maxevents, int32_t timeout)
{
    return do_epoll_wait(epfd, events, maxevents, timeout);
}
int32_t __wrap_fcntl64(int32_t s, int32_t cmd, ...)
{
    WRAP_VA_PARAM(s, cmd, lwip_fcntl, posix_api->fcntl64_fn);
}
int32_t __wrap_fcntl(int32_t s, int32_t cmd, ...)
{
    WRAP_VA_PARAM(s, cmd, lwip_fcntl, posix_api->fcntl_fn);
}
int32_t __wrap_ioctl(int32_t s, int32_t cmd, ...)
{
    WRAP_VA_PARAM(s, cmd, lwip_ioctl, posix_api->ioctl_fn);
}

int32_t __wrap_accept(int32_t s, struct sockaddr *addr, socklen_t *addrlen)
{
    return do_accept(s, addr, addrlen);
}
int32_t __wrap_accept4(int32_t s, struct sockaddr *addr, socklen_t *addrlen, int32_t flags)
{
    return do_accept4(s, addr, addrlen, flags);
}
int32_t __wrap_bind(int32_t s, const struct sockaddr *name, socklen_t namelen)
{
    return do_bind(s, name, namelen);
}
int32_t __wrap_connect(int32_t s, const struct sockaddr *name, socklen_t namelen)
{
    return do_connect(s, name, namelen);
}
int32_t __wrap_listen(int32_t s, int32_t backlog)
{
    return do_listen(s, backlog);
}
int32_t __wrap_getpeername(int32_t s, struct sockaddr *name, socklen_t *namelen)
{
    return do_getpeername(s, name, namelen);
}
int32_t __wrap_getsockname(int32_t s, struct sockaddr *name, socklen_t *namelen)
{
    return do_getsockname(s, name, namelen);
}
int32_t __wrap_getsockopt(int32_t s, int32_t level, int32_t optname, void *optval, socklen_t *optlen)
{
    return do_getsockopt(s, level, optname, optval, optlen);
}
int32_t __wrap_setsockopt(int32_t s, int32_t level, int32_t optname, const void *optval, socklen_t optlen)
{
    return do_setsockopt(s, level, optname, optval, optlen);
}
int32_t __wrap_socket(int32_t domain, int32_t type, int32_t protocol)
{
    return do_socket(domain, type, protocol);
}
ssize_t __wrap_read(int32_t s, void *mem, size_t len)
{
    return do_read(s, mem, len);
}
ssize_t __wrap_recv(int32_t sockfd, void *buf, size_t len, int32_t flags)
{
    return do_recv(sockfd, buf, len, flags);
}
ssize_t __wrap_send(int32_t sockfd, const void *buf, size_t len, int32_t flags)
{
    return do_send(sockfd, buf, len, flags);
}
ssize_t __wrap_recvmsg(int32_t s, struct msghdr *message, int32_t flags)
{
    return do_recvmsg(s, message, flags);
}
ssize_t __wrap_sendmsg(int32_t s, const struct msghdr *message, int32_t flags)
{
    return do_sendmsg(s, message, flags);
}
int32_t __wrap_close(int32_t s)
{
    return do_close(s);
}
int32_t __wrap_poll(struct pollfd *fds, nfds_t nfds, int32_t timeout)
{
    return do_poll(fds, nfds, timeout);
}
int32_t __wrap_ppoll(struct pollfd *fds, nfds_t nfds, const struct timespec *tmo_p, const sigset_t *sigmask)
{
    return do_ppoll(fds, nfds, tmo_p, sigmask);
}
int32_t __wrap_sigaction(int32_t signum, const struct sigaction *act, struct sigaction *oldact)
{
    return do_sigaction(signum, act, oldact);
}
pid_t __wrap_fork(void)
{
    return lstack_fork();
}
